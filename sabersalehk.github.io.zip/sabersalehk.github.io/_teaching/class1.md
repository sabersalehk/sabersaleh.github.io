---
title: "Lecturer - Physics 101"
collection: teaching
type: "Undergraduate course"
permalink: /teaching/course1
university: "University"
date: 2014-09-01
semester: "Fall 2014"
---

I even taught a class! Here are some more details.
