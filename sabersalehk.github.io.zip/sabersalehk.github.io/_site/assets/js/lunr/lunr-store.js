var store = [{
        "title": "software_package1",
        "excerpt":"Summary This package takes in two numbers and adds them together! ","categories": [],
        "tags": [],
        "url": "http://localhost:4000/code/software_package1",
        "teaser":null},{
        "title": "Publication 1",
        "excerpt":"Summary tl;dr Contribution This is what I did! Abstract Super details Download paper here Recommended citation: Name2 et al. “Publication 1”, 2012 (Journal 1) ","categories": [],
        "tags": [],
        "url": "http://localhost:4000/publications/publication1",
        "teaser":null},{
        "title": "Publication 2",
        "excerpt":"Summary Something, something. Contribution I did some MORE things! Abstract Download paper here Recommended citation ","categories": [],
        "tags": [],
        "url": "http://localhost:4000/publications/publication2",
        "teaser":null},{
        "title": "Lecturer - Physics 101",
        "excerpt":"I even taught a class! Here are some more details. ","categories": [],
        "tags": [],
        "url": "http://localhost:4000/teaching/course1",
        "teaser":null}]
