---
layout: archive
title: "Teaching"
permalink: /teaching/
author_profile: true
classes: wide
---

I am currently teaching the following two courses at Leiden University:
- Probability for Computer Scientists, Spring semesters
- Causal Inference, Spring semesters

In past few years, I taught the following courses several times in other institutes:
- Introduction to Machine Learning
- Algorithm Design
- Distributed Systems
- Causal inference