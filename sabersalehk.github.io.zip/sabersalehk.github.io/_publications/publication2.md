---
title: "Publication 2"
collection: publications
permalink: /publications/publication2
excerpt: "This is an example of a paper in prep"
date: 2018-05-03
venue: 'In Prep'
publ: "false"
---

### Summary
Something, something.

### Contribution
I did some MORE things!

### Abstract
[~~Download paper here~~](http://link.to.paper2/)

### Recommended citation