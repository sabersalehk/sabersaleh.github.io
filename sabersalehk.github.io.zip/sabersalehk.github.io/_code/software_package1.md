---
title: "software_package1"
collection: code
permalink: /code/software_package1
excerpt: "A package that calculates some numbers!"
date: 2018-05-15
repo: "https://github.com/user/reponame"
---
## Summary
This package takes in two numbers and adds them together!