---
layout: cv-archive
title: "CV"
permalink: /cv/
author_profile: true
redirect_from:
  - /resume
---

<style>
a.uline {text-decoration:underline;}
</style>

{% include base_path %}

<a href="../files/cv.pdf" class="uline">Click here for a full pdf copy of my CV</a>

## Education
---
**In Progress**<br>
Ph.D. in Knowledge<br>
University<br>
*Advisor: Prof. Albert Einstein*

**1990-2010**<br>
B.S. in Partying<br>
School<br>
*Advisor: Prof. Paul Dirac*

## Research experience
---

**2015 - Present**<br>
Position<br>
I accomplished some things.<br>
*Relevant Publications: <a href="../publications/publication1" class="uline">Name2 et al. 2016</a>*<br>


## Service and Outreach
---
**2013 - Present**<br>
Outreach<br>


## Publications
---
**Name2** et al. "Title of paper 1", 2016.



## Awards and Honors
---
Best Jekyll Theme, *Spring 2018*<br>


## Talks and Presentations
---
"Seminar 17", University Colloquium, *March 2018*


## Teaching
---
**Summer 1900**<br>
Primary Instructor<br>
*Quantum Field Theory 101*