---
layout: archive
title: "Talks and presentations"
permalink: /talks/
author_profile: true
classes: wide
---

{% for post in site.talks reversed %}
  {% include archive-single.html %}
{% endfor %}
