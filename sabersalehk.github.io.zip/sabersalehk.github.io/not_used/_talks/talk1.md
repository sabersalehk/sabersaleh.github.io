---
title: "Super Awesome Talk"
collection: talks
type: "Colloquium"
venue: "University"
date: 2018-02-16
location: "Atlantic Ocean"
---
I talked about this stuff!