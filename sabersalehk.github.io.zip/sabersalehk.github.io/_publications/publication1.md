---
title: "Publication 1"
collection: publications
permalink: /publications/publication1
excerpt: "We did some things and then published them."
date: 2012-03-20
venue: 'Journal'
classes: wide
---
## Summary
tl;dr

## Contribution
This is what I did!

## Abstract
Super details

[Download paper here](https://www.paper.link/)

## Recommended citation:
Name2 et al. "Publication 1", 2012 (Journal 1)