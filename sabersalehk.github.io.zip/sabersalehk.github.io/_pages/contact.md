---
layout: archive
title: "Contact"
permalink: /contact/
author_profile: true
classes: wide
---

**Contact Info:**

Address: Room 161, Snellius Gebouw, Niels Bohrweg 1, 2333 CA Leiden
<br>
Email address: s.salehkaleybar@liacs.leidenuniv.nl
<br>
Phone number: +31 71 527 2727
